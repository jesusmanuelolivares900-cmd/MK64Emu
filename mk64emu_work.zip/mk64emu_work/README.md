# MK64 Emu — proyecto base Android

Este ZIP contiene una **base de aplicación Android**, no un emulador terminado.
Actualmente permite seleccionar una ROM local y contiene una rutina C++ de lectura/validación. Los botones de modos solo muestran un aviso: todavía no ejecutan Mario Kart 64.

## Compilar el APK desde Android usando GitHub

1. Entra en https://github.com e inicia sesión.
2. Crea un repositorio nuevo llamado `MK64Emu` (puede ser privado).
3. Descomprime este ZIP y sube **el contenido de la carpeta `mk64emu`**, no la carpeta exterior `mk64emu` como subcarpeta.
4. Comprueba que en la raíz del repositorio se vean `app`, `core`, `build.gradle`, `settings.gradle` y `.github`.
5. Abre la pestaña **Actions**. Selecciona **Build APK** y pulsa **Run workflow** (o espera a que termine el primer flujo tras subir los archivos).
6. Cuando el trabajo termine con una marca verde, abre su ejecución y baja hasta **Artifacts**.
7. Descarga `mk64emu-apk`, descomprime el archivo descargado e instala `app-debug.apk`.

Si GitHub muestra un error rojo, abre el trabajo **Build APK** y comparte una captura del primer mensaje que diga `FAILURE` o `error`.

## Requisitos y límites actuales

- La compilación necesita conexión a Internet.
- El APK de depuración no está firmado para publicación en Play Store.
- No se incluye ninguna ROM. Usa únicamente una copia de un juego que tengas derecho a utilizar.
- La CPU MIPS R4300i, RSP, RDP/gráficos, audio, mandos y lógica de juego todavía no están implementados. Por eso, obtener el APK no significa que ya puedas jugar.
