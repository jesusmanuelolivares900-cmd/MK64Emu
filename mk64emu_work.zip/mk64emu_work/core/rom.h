#pragma once
#include <cstdint>
#include <string>
#include <vector>

enum class RomFormat { Z64_BigEndian, V64_ByteSwapped, N64_LittleEndian, Unknown };

struct RomInfo {
    RomFormat original = RomFormat::Unknown;
    std::string title;      // 20 chars
    std::string gameCode;   // e.g. NKTP
    uint8_t version = 0;
    uint32_t clock = 0, entry = 0, crc1 = 0, crc2 = 0;
    bool crcOk = false;
    bool isMarioKart64 = false;
};

// Detecta el formato por los 4 primeros bytes y lo normaliza a big-endian (z64).
bool rom_load(const std::vector<uint8_t>& raw, std::vector<uint8_t>& out, RomInfo& info, std::string& err);
