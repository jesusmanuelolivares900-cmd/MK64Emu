#include <jni.h>
#include <fstream>
#include <iterator>
#include "rom.h"
static std::vector<uint8_t> g_rom; static RomInfo g_info;
extern "C" JNIEXPORT jstring JNICALL Java_com_mk64emu_MainActivity_nativeLoadRom(JNIEnv* e, jobject, jstring p){
    const char* path=e->GetStringUTFChars(p,nullptr); std::ifstream f(path,std::ios::binary);
    std::vector<uint8_t> raw((std::istreambuf_iterator<char>(f)),{}); e->ReleaseStringUTFChars(p,path);
    std::string err; g_info=RomInfo();
    if(!rom_load(raw,g_rom,g_info,err)) return e->NewStringUTF(err.c_str());
    if(!g_info.isMarioKart64) return e->NewStringUTF("Esta ROM no es Mario Kart 64");
    if(!g_info.crcOk) return e->NewStringUTF("ROM corrupta (CRC incorrecto)");
    return e->NewStringUTF("");
}
extern "C" JNIEXPORT jstring JNICALL Java_com_mk64emu_MainActivity_nativeRomTitle(JNIEnv* e, jobject){ return e->NewStringUTF(g_info.title.c_str()); }
