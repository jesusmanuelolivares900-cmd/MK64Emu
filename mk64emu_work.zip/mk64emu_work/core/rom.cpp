#include "rom.h"
#include <cstring>
#include <algorithm>

static uint32_t be32(const uint8_t* p){ return (uint32_t)p[0]<<24|p[1]<<16|p[2]<<8|p[3]; }

// CRC de arranque N64 (algoritmo CIC-6102, usado por Mario Kart 64)
static void bootcrc(const uint8_t* rom, size_t size, uint32_t& c1, uint32_t& c2){
    auto rol=[](uint32_t v,uint32_t s){ s&=31; return s? (v<<s)|(v>>(32-s)) : v; };
    uint32_t t1,t2,t3,t4,t5,t6;
    t1=t2=t3=t4=t5=t6=0xF8CA4DDC;
    for(size_t i=0x1000;i<0x1000+0x100000 && i+4<=size;i+=4){
        uint32_t d=be32(rom+i);
        if(t6+d<t6) t4++;
        t6+=d; t3^=d;
        uint32_t r=rol(d,d&0x1F);
        t5+=r;
        if(t2>d) t2^=r; else t2^=t6^d;
        t1+=t5^d;
    }
    c1=t6^t4^t3; c2=t5^t2^t1;
}

bool rom_load(const std::vector<uint8_t>& raw, std::vector<uint8_t>& out, RomInfo& info, std::string& err){
    if(raw.size()<0x1000 || raw.size()>64u*1024*1024){ err="Tamaño de archivo no válido"; return false; }
    out=raw;
    uint32_t m=be32(raw.data());
    if(m==0x80371240) info.original=RomFormat::Z64_BigEndian;
    else if(m==0x37804012){ info.original=RomFormat::V64_ByteSwapped; for(size_t i=0;i+1<out.size();i+=2) std::swap(out[i],out[i+1]); }
    else if(m==0x40123780){ info.original=RomFormat::N64_LittleEndian; for(size_t i=0;i+3<out.size();i+=4){ std::swap(out[i],out[i+3]); std::swap(out[i+1],out[i+2]); } }
    else { err="No parece una ROM de N64 (cabecera desconocida)"; return false; }
    // 0x37804012 = .v64/.n64 con pares de bytes intercambiados (el caso de tu ROM); 0x40123780 = little-endian completo.
    info.clock=be32(&out[4]); info.entry=be32(&out[8]);
    info.crc1=be32(&out[0x10]); info.crc2=be32(&out[0x14]);
    info.title.assign((const char*)&out[0x20],20);
    while(!info.title.empty() && (info.title.back()==' '||info.title.back()==0)) info.title.pop_back();
    info.gameCode.assign((const char*)&out[0x3B],4);
    info.version=out[0x3F];
    uint32_t c1,c2; bootcrc(out.data(),out.size(),c1,c2);
    info.crcOk=(c1==info.crc1&&c2==info.crc2);
    info.isMarioKart64 = info.gameCode.compare(0,3,"NKT")==0;
    return true;
}
