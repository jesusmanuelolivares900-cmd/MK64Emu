#include "rom.h"
#include <cstdio>
#include <fstream>
#include <iterator>
int main(int argc,char**argv){
    std::ifstream f(argv[1],std::ios::binary); std::vector<uint8_t> raw((std::istreambuf_iterator<char>(f)),{});
    std::vector<uint8_t> rom; RomInfo i; std::string e;
    if(!rom_load(raw,rom,i,e)){ printf("ERROR: %s\n",e.c_str()); return 1; }
    printf("formato original: %d\ntitulo: '%s'\ncodigo: %s v%d\nentry: %08X\ncrc: %08X %08X ok=%d\nmk64=%d\n",(int)i.original,i.title.c_str(),i.gameCode.c_str(),i.version,i.entry,i.crc1,i.crc2,i.crcOk,i.isMarioKart64);
}
