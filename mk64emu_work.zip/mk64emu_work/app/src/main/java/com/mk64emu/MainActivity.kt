package com.mk64emu

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*

/** Menú: pide la ROM, la valida con el núcleo C++ y habilita Online / Local / Modos. */
class MainActivity : Activity() {
    companion object { init { System.loadLibrary("mk64core") } }
    external fun nativeLoadRom(path: String): String   // devuelve "" si OK, o el mensaje de error
    external fun nativeRomTitle(): String

    private lateinit var status: TextView
    private lateinit var menu: LinearLayout

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        status = TextView(this).apply { text = "Selecciona tu ROM de Mario Kart 64 para empezar"; textSize = 18f }
        val pick = Button(this).apply { text = "Elegir ROM"; setOnClickListener { pickRom() } }
        menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = LinearLayout.GONE }
        listOf("Online", "Local (1-4 jugadores)", "Grand Prix", "Time Trial", "Versus", "Batalla").forEach { name ->
            menu.addView(Button(this).apply { text = name; setOnClickListener { start(name) } })
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48)
            addView(status); addView(pick); addView(menu)
        })
    }

    private fun pickRom() = startActivityForResult(
        Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 1)

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri: Uri = data?.data ?: return
        // Copia a almacenamiento interno (la app no distribuye la ROM)
        val dst = java.io.File(filesDir, "mk64.rom")
        contentResolver.openInputStream(uri)!!.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        val err = nativeLoadRom(dst.absolutePath)
        if (err.isEmpty()) { status.text = "ROM válida: ${nativeRomTitle()}"; menu.visibility = LinearLayout.VISIBLE }
        else { status.text = "ROM no válida: $err"; menu.visibility = LinearLayout.GONE }
    }

    private fun start(mode: String) {
        Toast.makeText(this, "$mode: el núcleo de emulación aún no está implementado", Toast.LENGTH_SHORT).show()
    }
}
